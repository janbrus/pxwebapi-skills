# Agent Skill: SSB Historisk statistikk

En [Agent Skill](https://agentskills.io) — en `SKILL.md` med arbeidsflyt og regler pluss referansefiler. Den lærer AI-verktøy som Claude og ChatGPT å navigere SSBs digitaliserte historiske publikasjoner (1828–2010) under `https://www.ssb.no/a/histstat/`.

## Hva skillen gjør

- **Starter på huben `/a/histstat/publikasjoner/`** — SSBs autoritative, `curl`-bare publikasjonskatalog (organisert *Etter emne* og *Etter serie*) som styrer arbeidsflyten
- Guider AI-assistenten til riktig publikasjon for spørsmål om historiske norske tall — typisk fra **før ca. 1980** der `ssb-pxwebapi-v2` har begrenset dekning
- Anbefaler *Historisk statistikk*-utgavene (hs1978, hs1968, hs1994) som førstevalg for brede tidsserier
- Bruker `statbank-histu.html` som bro: identifiserer historiske tidsserier som ennå publiseres i Statistikkbanken og delegerer til `ssb-pxwebapi-v2` for live tall
- Kjenner publikasjonsstrukturen: NOS-serien (1828–2010), 25 emnesider, 12 serier (inkl. SØS-forskningsmonografier), 9 periodika, filnavn-konvensjoner og katalogplassering
- Returnerer URL til PDF/HTML pluss kontekst (serie, år, tema) — parser ikke PDF-innhold

## Når den utløses

Triggers på norske begreper som "historisk statistikk", "NOS", "Norges offisielle statistikk", "folketelling 1769/1801/1865/…", "Statistisk årbok", "tall fra 1800-tallet", samt årstall før 1980 kombinert med statistikkbegreper (befolkning, lønn, priser, handel, jordbruk, fiske, industri, skole, fattigvesen). Også engelsk: "Norwegian historical statistics", "Statistics Norway historical", "Norway 19th century data".

## Filstruktur

```
ssb-histstat-skill/
├── SKILL.md                              # Hovedinstruksjoner: arbeidsflyt + decision tree
├── README.md                             # Denne filen
├── CHANGELOG.md                          # Endringslogg — versjon står i SKILL.md-frontmatter
├── ssb-histstat-skill.zip                # Ferdigpakket skill — last opp i Claude.ai, eller pakk ut i .agents/skills/ for ChatGPT/Codex
└── references/
    └── structure.md                      # Annotering av huben /a/histstat/publikasjoner/: 25 emnesider, 12 serier, 9 periodika, bibliografi, filnavn-konvensjoner
```

`CLAUDE.md` og `scripts/` i repoet er vedlikeholder-interne og følger ikke med i pakken.

## Installasjon

### Claude.ai og Claude desktop

1. Last ned [ssb-histstat-skill.zip](ssb-histstat-skill.zip) (*Download raw file* på GitHub), eller bygg den fra repoet med `scripts/build_zip.sh` (ikke zip mappen selv — da følger `CLAUDE.md` og `scripts/` med). Pakken har toppmappe `ssb-histstat/`
2. Gå til **Settings > Skills** → **+ Add** → **Upload skill**
3. Velg ZIP-filen

Under **Settings > Capabilities** må *Cloud code execution and file creation* være på. For å oppdatere laster du ned den nye ZIP-filen, åpner skillen under **Settings > Skills** og velger **⋮** → **Replace**. [Skjermbilder](https://github.com/janbrus/pxwebapi-skills#claudeai-og-claude-desktop).

### Claude Code

Pakk ut zip-filen i skills-katalogen. Toppmappen har det installerte navnet `ssb-histstat` (mappen i repoet heter `ssb-histstat-skill`):

```bash
# Globalt (tilgjengelig i alle prosjekter)
unzip ssb-histstat-skill.zip -d ~/.claude/skills/

# Per prosjekt
unzip ssb-histstat-skill.zip -d .claude/skills/

# Eller symlenke fra roten av et klonet repo — da holder git pull kopien oppdatert
ln -s "$PWD/ssb-histstat-skill" ~/.claude/skills/ssb-histstat
```

### ChatGPT og Codex

ChatGPT og Codex leser skills i samme format fra `~/.codex/skills/` for alle prosjekter (Windows: `%USERPROFILE%\.codex\skills\`) og fra `.agents/skills/` for ett prosjekt (se [OpenAIs dokumentasjon](https://developers.openai.com/codex/skills/)). Pakk ut zip-filen der. Toppmappen `ssb-histstat/` har det installerte navnet:

```bash
# Mac/Linux
unzip ssb-histstat-skill.zip -d ~/.codex/skills/

# Windows (PowerShell)
Expand-Archive ssb-histstat-skill.zip -DestinationPath $env:USERPROFILE\.codex\skills
```

ChatGPTs `$skill-installer` henter mapper, ikke zip-filer, og tar da med de repo-interne filene. Frittstående skills er tilgjengelige i ChatGPT desktop-app, Codex CLI og IDE-utvidelsen; på web og mobil må skillen pakkes som plugin.

## Bruk sammen med søsken-skillen

Skillen er **kompletterende til `ssb-pxwebapi-v2`**, ikke en erstatning. Tommelfingerregel:

- Aktuelle/nyere tall, tidsserie som fortsatt oppdateres → `ssb-pxwebapi-v2`
- Historiske tabeller, eldre folketellinger, NOS-publikasjoner, Statistisk årbok → denne skillen
- Tidsserie som *starter* historisk men fortsetter til i dag → start her (sjekk `statbank-histu.html`), deleger så til `ssb-pxwebapi-v2`

Installer begge skillene (Claude.ai, Claude Code eller ChatGPT) for komplett dekning av norsk offisiell statistikk fra 1769 til i dag.

## Hva skillen IKKE gjør

- Ikke parsing av PDF-innhold til tabelldata — returnerer URL og kontekst, brukeren åpner selv
- Ikke moderne tall — bruk `ssb-pxwebapi-v2`
- Ikke svensk eller dansk historisk statistikk

## Lisens

Skillen (`SKILL.md`, `references/` og skriptene) er lisensiert under [MIT-lisensen](https://github.com/janbrus/pxwebapi-skills/blob/main/LICENSE), © 2026 Jan Bruusgaard. Lisensteksten ligger i repo-roten og følger med i zip-filen som `LICENSE`. MIT gjelder skillen, ikke dataene den henter — de har sin egen lisens, se under.

Skillen er et hjelpemiddel for å navigere SSBs åpne historiske arkiv. Materialet under `/a/histstat/` er publikasjoner som SSB har gjort fritt tilgjengelig; eldre verk er typisk i public domain, mens nyere er dekket av SSBs lisens ([CC BY 4.0](https://www.ssb.no/diverse/lisens)). Sjekk den enkelte publikasjon for spesifikke vilkår.
