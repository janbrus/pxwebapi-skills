# Feilsøking for PxWebApi v2

Vanlige feilscenarier og løsninger. Feilresponsen ligner RFC 7807, men er ikke en full implementasjon: `type` er en ren streng («Parameter error»), ikke en URI, og `detail` gjentar i beste fall bare `title`. **Diagnosefeltet er `title`.** Unntaket er ugyldige parameterverdier (`outputFormat=nonsense`, `pageSize=abc`): de gir `application/problem+json` med `type` som URI, `title` «One or more validation errors occurred.» og `errors`, som navngir parameteren.

**Innhold**

1. HTTP-feilkoder: 400 (med `title`-tabell), curl «bad range in URL», 403, 404, 429, 500, 503
2. Vanlige problemer: for mange celler, tomme søkeresultater, avsluttet tabell, manglende kommuner, NULL-verdier og standardtegn, feil enheter, brudd over tid
3. Sjekk API-konfigurasjon: `/config`, `maxDataCells`, `sourceReferences`

---

## HTTP-feilkoder

### 400 Bad Request

Ugyldig forespørsel. **Diagnostiser fra `title`, ikke fra `detail`** — `detail` finnes som regel ikke. Verifiserte former (2026-08-30):

| Situasjon | Payload |
|---|---|
| Ukjent variabel | `{"type":"Parameter error","title":"Non-existent variable","status":400}` |
| Ugyldig verdikode | `… "title":"Non-existent value" …` |
| Manglende obligatorisk variabel | `… "title":"Missing selection for mandantory variable" …` (sic, `mandantory`) |
| For mange celler | `… "title":"Too many cells selected","detail":"Too many cells selected"` |
| Komma-uttrykk i GET uten hakeparenteser | `… "title":"Illegal selection expression" …` |
| Ukjent kodeliste-ID | `… "title":"Non-existent codelist" …` |
| `outputFormatParams` med json-stat2 | `… "title":"Unsupported output format","detail":"Unsupported output format"` |
| Ukjent tabell, fra `/data` | `… "title":"Non-existent table","status":404` — men HTTP **400** (fra `/tables/{id}` og `/metadata`: 404) |
| Ugyldig parameterverdi | `{"type":"https://tools.ietf.org/html/rfc9110#section-15.5.1","title":"One or more validation errors occurred.","status":400,"errors":{"pageSize":[…]}}` |

`detail` settes i «Too many cells», «Unsupported output format» og «Saved query not found» (404), og gjentar da bare `title`. Formen er identisk hos SCB, så en feilhåndtering skrevet mot SSB virker også der.

**Vanlige årsaker:**

- **Ukjent variabelkode** — `variableCode` i selection matcher ikke metadata. Variabel- og verdikoder er *ikke* case-sensitive (`region`, `contentscode`, `personer1` og `TOP(1)` aksepteres — verifisert 2026-09-09), så feilen skyldes at koden ikke finnes, ikke stor/liten bokstav. `Region` finnes ikke i KOSTRA-tabellene — der heter variabelen `KOKkommuneregion0000`/`KOKfylkesregion0000`/`KOKbydelsregion0000`, se `kostra.md`.
- **Ugyldig verdikode** — Koden finnes ikke i tabellen. Sjekk `category.index` i metadata. En kode fra en summerende kodeliste (`F-03`, `K-3103`, `F00-04`) gir denne feilen hvis `codelist[Var]` mangler. En kode med `+` (`105+`) må skrives `%2B` i en GET-URL — ellers blir `+` et mellomrom. I KOSTRA kan en `KOS…`-kode fra i fjor være borte, fordi variablene byttes ut når rapporteringskravene endres — hent metadata på nytt.
- **Feil tidsformat** — Bruker `"2024"` i en månedlig tabell (skal være `"2024M01"`).
- **For mange celler** — Resultatet overstiger `maxDataCells` fra `/config`.
- **Manglende obligatorisk variabel** — Variabel med `elimination: false` mangler fra selection. I KOSTRA-tabellene gjelder det nesten alle dimensjoner — også region (`KOKkommuneregion0000`), funksjon, art og regnskapsomfang.
- **Ugyldig kodeliste-ID** — Kodelisten finnes ikke for denne variabelen. Kodeliste-ID-er *er* case-sensitive: `agg_kommfylker` gir `Non-existent codelist`.
- **`range()`, `top(N, offset)` eller `bottom(N, offset)` i GET uten hakeparenteser** — komma er listeskilletegn i URL-en, så uttrykket deles i to. Skriv `valueCodes[Tid]=[range(2020,2022)]`. Gjelder ikke POST. Se `codelists-and-filters.md`.
- **Manglende `OutputFormatParams` i `POST /savedqueries`** — feltet er obligatorisk i request-bodyen selv om verdien er tom. Send `"outputFormatParams": []` hvis du ikke trenger noen. Symptom: `400 — "The OutputFormatParams field is required."`

**Løsning:** Hent metadata på nytt, sammenlign variabelkoder og verdikoder nøyaktig.

### curl: «bad range in URL» er ikke en API-feil

curl tolker `[` og `]` som sitt eget «globbing»-mønster. En URL med `valueCodes[Region]=…` feiler derfor lokalt, før noe er sendt:

```
curl: (3) bad range in URL position 66:
```

Bruk `curl -g` (`--globoff`), eller URL-kod hakeparentesene som `%5B`/`%5D` — API-et godtar begge. Det samme gjelder `[range(2020,2022)]`-uttrykk. Får du ingen JSON-respons i det hele tatt, sjekk dette først.

`-g` koder ingenting. En 400 med HTML-siden «Your client has issued a malformed or illegal request» betyr som regel rå æ, ø eller å i URL-en. Prosentkod dem (`ø` → `%C3%B8`), eller bruk `curl -G --data-urlencode "query=…"` (verifisert 2026-10-14).

### 403 Forbidden

Forespørselen er forstått men nektet.

**Vanlige årsaker:**

- Tabellen er merket som ikke tilgjengelig via API
- Lagret spørring tilhører en annen bruker/sesjon

### 404 Not Found

Ressursen finnes ikke.

**Vanlige årsaker:**

- Feil tabell-ID (skal være et tall som streng, f.eks. `"07459"`)
- Tabellen er erstattet og fjernet helt (`Non-existent table`; fra `/data` kommer samme feil som HTTP 400). SSB lar ikke alltid en erstattet tabell stå som `discontinued`, så en tabell-ID du husker eller har fått oppgitt, kan være borte. Slå opp ID-en på [Endringer i statistikkbanktabeller](https://www.ssb.no/statbank/hvordan-bruke-statistikkbanken/endringer-i-statistikkbanktabeller), der arkivet for 2016–2025 er lenket nederst og ny tabell-ID står oppgitt. Søk etter temaet bare hvis den ikke står der. Eksempel: 11038 gir 404, og siden oppgir 14890 (verifisert 2026-10-23)
- Feil saved query-ID (`Saved query not found`)
- **URL-en er lengre enn ca. 2 100 tegn** — API-et svarer 404, ikke 400, og svaret er webserverens HTML-side «404 - File or directory not found», ikke JSON. JSON med `Non-existent table` betyr at tabellen mangler; HTML betyr at URL-en er for lang. Grensen er målt 2026-09-09 på 07459: 400 distinkte kommunekoder (2 092 tegn) gir 200, 410 koder (2 142 tegn) gir 404. Bytt lange verdilister mot `*`, `?`, `from()`/`to()`/`[range()]` eller en kodeliste, eller bruk POST, som ikke har lengdegrensen

**Løsning:** Bruk `GET /tables?query=...` for å finne riktig ID. Er URL-en lang, kort den ned før du konkluderer med at ressursen mangler.

### 429 Too Many Requests

Rate-limiting. Du har sendt for mange forespørsler.

**Løsning:** Vent til tidsvinduet nullstilles og prøv igjen. Kjør store spørringer sekvensielt — vent på svaret før neste sendes, ikke parallelt. Grensen står i `x-ratelimit-*`-responsheaderne (ikke lenger i `/config`): `x-ratelimit-policy: 40;w=60s` betyr 40 kall per 60 sekunder, og `x-ratelimit-remaining` viser gjenstående kall i inneværende vindu. Se `api-details.md` for full headeroversikt.

### 500 Internal Server Error

**Gjentatt verdikode.** Oppgir du samme kode to ganger i samme variabel — `valueCodes[Region]=0301,0301`, eller `["0301", "0301"]` i en POST-body — svarer API-et 500 med **tom body**, ikke 400 med forklaring. To like koder er nok. Verifisert 2026-09-09 hos SSB. Latvia gir også 500; SCB gir 500 i `Tid` og `ContentsCode`, men fjerner dubletter i `Region` stille (2026-10-28).

Overlapp mellom et uttrykk og en enkeltkode er derimot uproblematisk: `valueCodes[Tid]=2026,top(1)` gir 200 selv når `top(1)` også er 2026 — det er bare bokstavelig like koder som feiler. Bygger du seleksjonen programmatisk (fra en løkke, en fil eller en union av flere kilder), dedupliser lista før du sender den.

**Ukjent kodeliste-ID i `GET /codelists/{id}`** gir også 500 med tom body, ikke 404 — også når bare store/små bokstaver er feil (`agg_kommfylker`). I en dataspørring gir samme feil 400 `Non-existent codelist`. Verifisert 2026-10-10.

### 503 Service Unavailable

Tjenesten er nede eller under oppdatering. Metadata oppdateres kl. 05.00 og 11.30, og tabellene er utilgjengelige imens; rundt kl. 08.00 er belastningen høy (se `api-details.md`). Vent og prøv igjen. Får du ikke svar, gjelder Fallback i `SKILL.md`: si at data ikke kunne hentes — ikke fyll tomrommet med tall fra hukommelsen.

---

## Vanlige problemer

### For mange celler

**Symptom:** 400-feil med melding om at resultatet overstiger cellegrensen. Grensen teller alle celler i uttrekket, også tomme.

**Beregning:** Antall celler = produktet av antall verdier per variabel. Eksempel:
- 400 kommuner × 2 kjønn × 100 aldre × 40 år = 3 200 000 celler
- 34 097 grunnkretser × 28 år i 04317 = 954 716 celler — ett år går (34 097), alle år ikke. Filtrer på kommuneprefiks (`0301*`) eller bruk `agg_GrkretsNy`; se «Regionale nivåer under kommune» i `codelists-and-filters.md`

**Løsning (i prioritert rekkefølge):**

1. Begrens Tid: `top(5)` i stedet for alle år
2. Begrens Region: velg spesifikke kommuner/fylker, eller bruk kodeliste for fylkesnivå
3. Bruk kodeliste for aldersaggregering: `agg_FemAarigGruppering`
4. Filtrer på ContentsCode: velg kun den måleenheten du trenger
5. Utelat variabler med `elimination: true`

**Tips:** Hent defaultselection først — den er designet for å holde seg innenfor cellegrensen.

### Tomme eller uventede søkeresultater

- Prøv andre søkeord eller synonymer ("folkemengde" vs "befolkning" vs "innbyggere")
- SSB bruker fagtermer: "konsumprisindeks" ikke "KPI", "sysselsatte" ikke "ansatte"
- Bruk `includeDiscontinued=true` hvis du trenger historiske serier
- Bruk `pastDays=30` for å finne nylig oppdaterte tabeller
- Paginering: sjekk `page.totalPages` — det kan finnes flere resultatsider

### Avsluttet tabell (`discontinued`)

Tabeller avsluttes, og serien fortsetter ofte i en ny tabell. Bruker du en avsluttet tabell, si det og oppgi siste periode. Finn etterfølgeren når den finnes: tabellnoten nevner den av og til (03013 → 14700), ellers slår du opp ID-en på [Endringer i statistikkbanktabeller](https://www.ssb.no/statbank/hvordan-bruke-statistikkbanken/endringer-i-statistikkbanktabeller), som også lister tabeller som er fjernet helt (se 404 over). Endringer fra 2016–2025 står i [arkivet](https://www.ssb.no/statbank/hvordan-bruke-statistikkbanken/endringer-i-statistikkbanktabeller-arkiv), ikke på selve endringssiden.

### Manglende kommuner

Kommunesammenslåingene i 2020 og fylkesdelingen i 2024 endret mange kommunekoder. For eksempel ble gamle Oppegård (0217) og Ski (0213) til nye Nordre Follo (3020). Hvilke koder som endret seg når, viser Klass (`changes`, se `klass-vardok.md`).

**Løsning:**

- Sjekk metadata for gyldige kommunekoder i tabellen
- Bruk kodeliste for "sammenslåtte kommuner" for konsistente tidsserier
- Bruk fylkesaggregering med `agg_KommFylker` for å unngå kommuneproblemer

### NULL-verdier i data

Normalt. Ikke alle kombinasjoner har data. Spesielt vanlig for detaljerte nedbrytninger (kommune × alder × kjønn × næring).

Sjekk `status`-objektet i json-stat2-responsen. SSBs gjeldende standardtegn (fra 2021):
- `"."` = ikke mulig å oppgi tall (kategorien var ikke i bruk)
- `".."` = tallgrunnlag mangler (ikke innkommet eller for usikre til å publiseres)
- `":"` = vises ikke av konfidensialitetshensyn (for å unngå identifisering)

KOSTRA prikker tall som bygger på færre enn 3 enheter (barnevern, sosialhjelp, kvalifiseringsstønad, bolig) eller færre enn 5 brukere (pleie og omsorg), og for enkelte økonomiske nøkkeltall er landsgjennomsnittet *med* Oslo prikket — bruk `EAKUO` (Landet uten Oslo). Se `kostra.md`.

I eldre tabeller (før 2021) kan du også finne:
- `"..."` = oppgave mangler foreløpig
- `"-"` = null. Tallet er 0, men bruken har vært tvetydig: vis `-`, og ikke regn med det som 0 (vedlikeholder, 2026-10-01). Verdien i `value` er `null`. Funnet i 4 av 88 tabeller i et sveip 2026-10-02, blant dem 08205
- `"*"` = foreløpig tall. **Står på en celle som har tall**, så det er et flagg, ikke et hull: 09842 (BNP per innbygger) har `*` på 2023–2024 med tallene i `value`, og tabellens `note` forklarer tegnet. Vis tallet sammen med flagget. Se `json-stat2.md` under `status`

Se https://www.ssb.no/diverse/standardtegn-i-tabeller (engelsk: https://www.ssb.no/en/diverse/standardtegn-i-tabeller)

### Feil tall eller uventede enheter

- Sjekk `ContentsCode` i metadata — tabellen kan ha flere målevarianter
- Sjekk `category.unit` for enhet (f.eks. "personer", "prosent", "1000 kr", "indeks")
- Sjekk om verdiene er indeksert (KPI: 2025=100)
- Sjekk `extension.measuringType` (Stock, Flow, Average)
- Sjekk `extension.priceType` (Current = løpende priser, Fixed = faste priser)
- Sjekk `extension.adjustment` (sesongjustert, arbeidsdagskorrigert)

### Data ser "feil ut" over tid

- Kommunesammenslåingene i 2020 og kodeskiftet i 2024 bryter tidsserier på kommunenivå
- Næringsklassifisering: SSB er i overgang fra SN2007 til SN2025 (2026–2029, statistikk for statistikk; de fleste SN2007-tabeller avsluttes, konkursene går parallelt). Samme kode, bokstav eller femsifret, kan være ulik næring i de to standardene — se «Næringskoder: SN2007 → SN2025» i `codelists-and-filters.md`
- KOSTRA: KOSTRA-gruppene (`EKGnn`) ble revidert fra 2020 (brudd 2019/2020, ofte obligatorisk note); tabellene ble omstrukturert i 2015 (eldre serier ligger i avsluttede tabeller); variabler og tabeller byttes ut når rapporteringskravene endres (sosialtjenesten 2015–2021 → nye tabeller fra 2022) — tomme år for en variabel betyr ofte at den ikke fantes; mars-tall er ureviderte til juni uten `status`-flagg; Landet og Landet uten Oslo er estimerte og veide tall — se `kostra.md`
- KPI-basisår endres periodisk (nå 2025=100)
- Nasjonalregnskapet revideres (foreløpige → endelige tall)

---

## Sjekk API-konfigurasjon

Bruk `GET /config` for å se gjeldende grenser:

Full respons, verifisert 2026-08-30:

```json
{
  "apiVersion": "2.3.2",
  "appVersion": "2.5.0+build.30",
  "languages": [{"id": "no", "label": "Norsk"}, {"id": "en", "label": "English"}],
  "defaultLanguage": "no",
  "maxDataCells": 800000,
  "maxCallsPerTimeWindow": 0,
  "timeWindow": 0,
  "license": "https://www.ssb.no/en/diverse/lisens",
  "sourceReferences": [
    {"language": "en", "text": "Source: Statistics Norway"},
    {"language": "no", "text": "Kilde: Statistisk sentralbyrå"}
  ],
  "defaultDataFormat": "json-stat2",
  "dataFormats": ["json-stat2", "csv", "px", "xlsx", "html", "json-px", "parquet"],
  "features": [{"id": "CORS", "params": [{"key": "enabled", "value": "True"}]}]
}
```

`sourceReferences` er verdt å kjenne: det er SSBs egen kildehenvisningsstreng per språk («Kilde: Statistisk sentralbyrå» / «Source: Statistics Norway»), ved siden av kortformen skillen bruker i Steg 5 («Kilde: SSB, tabell {id}. Sist oppdatert: {YYYY-MM-DD}.»).

Verdiene kan endre seg — hardkod dem ikke. NB: `maxCallsPerTimeWindow` og `timeWindow` er nullstilt til `0` og ikke lenger i bruk; rate limit leses fra `x-ratelimit-*`-headerne — se `api-details.md`.
